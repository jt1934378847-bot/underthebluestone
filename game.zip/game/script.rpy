﻿# 游戏《青石之下》核心逻辑脚本

define config.name   = "青石之下"
define config.version = "1.0"
define config.has_sound  = True
define config.has_music  = True
define config.window_title = "青石之下"

# 定义角色
define n = Character("宁寻", color="#A5B1C2")  
define lz = Character("林芷", color="#82CCDD")  
define cst = Character("陈思彤", color="#38ADA9") 
define l = Character("林远", color="#4A69BD")   
define z = Character("张浩", color="#95A5A6")   
define zy = Character("周瑶", color="#747D8C")  
define p = Character("警察", color="#2C3E50")   
define sys = Character("系统提示", color="#E74C3C") 

# 定义角色立绘
image nx = "nx.png"
image nx closeeye = "nx_closeeye.png"
image nx shock = "nx_shock.png"
image nx 9 = "nx_9.png"
image ly = "ly.png"
image lz = "lz.png"
image zh = "zh.png"
image zh flust = "zh_flust.png"
image zy = "zy.png"
image cst = "cst.png"
image gx = "gx.png"

# 这是一个模拟灯光闪烁的特效
transform flickering_light:
    alpha 1.0       # 正常亮着
    pause 1.5       # 持续1.5秒
    
    alpha 0.3       # 突然变暗
    pause 0.1       # 只暗0.1秒
    
    alpha 0.8       # 稍微亮一点
    pause 0.05
    
    alpha 0.2       # 又快黑了
    pause 0.2
    
    alpha 1.0       # 重新亮起来
    pause 2.0       # 稳定2秒
    
    alpha 0.4       # 突然又暗一下
    pause 0.1
    
    alpha 1.0       # 恢复
    pause 1.0
    
    repeat          # 无限循环

# 定义背景、音频的占位符
image library_ext      = "library_ext.png" # 图书馆外部/情绪神秘感
image library          = "library.png" # 图书馆内部
image black            = Solid("#000000") # 黑背景
image stairway         = "stairway.png" # 楼道
image room_chen        = "room_chen.png" # 陈思彤房间
image school           = "school.png" # 青石中学
image flashback_horror = "flashback_horror.png" # 阴暗恐怖的幻觉背景
image n_room_9         = "n_room_9.png" # 9岁的宁寻房间
image forum            = "forum.png" # 复古论坛底图
image factory          = "factory.png" # 工厂门口
image lin_door         = "lin_door.png" # 林远家楼梯间门口
image lin_home         = "lin_home.png" # 林远家客厅
image photo            = "photo.png"


# 定义音频：
define audio.bgm_sad = "audio/bgm_sad.mp3"
define audio.bgm_horror = "audio/bgm_horror.mp3"
define audio.clock = "audio/clock.mp3"
define audio.door = "audio/door.mp3"
define audio.footsteps = "audio/footsteps.mp3"
define audio.page = "audio/page.mp3"
define audio.heartbeat = "audio/heartbeat.mp3"
define audio.knock = "audio/knock.mp3"
define audio.flashback = "audio/flashback.mp3"
define audio.jw = "audio/jw.mp3"
define audio.ms = "audio/mistake.mp3"

# 定义全局变量与特效
default notebook_marked   = []    
default photo_bright      = 50    
default show_notebook_icon = False

default input_name_1 = ""    
default input_name_2 = ""      
default search_term = ""
default input_pw = "" 
default input_time = "" 

transform fade_in_line(delay_time):
    alpha 0.0             
    pause delay_time      
    linear 1.5 alpha 1.0  

# 前言界面
screen prologue_auto():
    #modal True 
    vbox:
        xalign 0.5   
        yalign 0.5   
        spacing 15 
        
        text "你叫宁寻，二十六岁，是一名图书管理员。" at fade_in_line(0.0)
        text "这座城市有很多图书馆，而你工作的那家藏在一条老街的尽头。" at fade_in_line(2.5)
        text "很少有人来，来的也大多是常客。" at fade_in_line(5.0)
        text "你喜欢这样，安静、可控、没有意外。" at fade_in_line(7.5)
        null height 30 
        text "你用了十七年，把自己活成了一潭死水。" at fade_in_line(11.0)
        text "没人知道这潭死水下面埋着什么。" at fade_in_line(13.5)

# 笔记本 UI 界面
screen notebook_index():
    zorder 100
    add Solid("#00000088") 

    modal True
    frame:
        xalign 0.5
        yalign 0.5
        padding (40, 40)
        background "#333333"

        vbox:
            spacing 20
            xalign 0.5
            text "【陈思彤的笔记本】" size 30 xalign 0.5 bold True
            text "请选择要查看的页面，查阅完毕后可点击最下方。" size 15 xalign 0.5 color "#CCCCCC"
            null height 20 

            # 30个页面的按钮网格 (5列6行)
            grid 5 6:
                xalign 0.5
                spacing 25
                for i in range(1, 31):
                    textbutton "第 [i] 页":
                        xsize 140       
                        ysize 50       
                        text_xalign 0.5 
                        text_yalign 0.5 
                        text_size 24    

                        action Return(i)
                     
            
            textbutton "【结束查阅】":
                xalign 0.5
                text_size 25
                text_color "#e74c3c"
                action Return("solve")# ============================================================
    

label start:
    # 序言
    scene library_ext with dissolve
    play music bgm_sad fadein 2.0
    show screen prologue_auto
    pause 18

    hide screen prologue_auto with dissolve
    stop music fadeout 2.0
    scene black with dissolve
    
    jump chapter_1

label chapter_1:
    # 【一、灰烬与来访者】
    scene black with fade
    centered "第一章：灰烬与来访者"
    
    play music "bgm_horror.mp3" fadein 1.0
    scene library with dissolve 
    "（图书馆）"
    show nx with dissolve
    "你站在服务台后面，从抽屉里抽出一本快散架的小说。"
    
    play sound clock
    queue sound door
    "老钟敲了一下，门开了。"
    
    show nx with dissolve:
        xoffset -400
    
    p "“你是宁寻？”"
    n "“是。”"
    p "“认识陈思彤吗？”"
    
    "你脑海里浮现一个马尾辫、帆布包的女人。"
    "她总来借插画集，还书的时候会顺手帮你把旁边的书也摆整齐。"
    
    n "“认识，她是这里的常客。”"
    "警察沉默了两秒。"
    p "“她死了。”"
    
    show nx shock with dissolve
    "你手里的胶水挤出来一大坨，糊在小说的封皮上。"
    "你低头看了一眼，拿纸巾擦掉，动作很慢。"
    
    show nx 
    p "“她最近有没有什么异常？”"
    "......"
    n "“没有。”"
    p "“有没有提过什么人？”"
    n "“没有。”"
    
    hide nx 
    show nx at center with move 
    
    "警察看了你一眼，留下名片，走了。"
    play sound clock
    "老钟又敲了一下。"
    
    "你盯着桌上那本快散架的小说。"
    "那是三天前，陈思彤最后一次来图书馆时还的。"
    
    scene black with fade
    "【三天前】"
    scene library with dissolve
    show cst with dissolve:
        xoffset 400
    show nx  with dissolve:
        xoffset -400
    
    "那天的陈思彤看起来很疲惫，她把一本书推到你面前。"
    n "是来还书吗？"
    cst "“不，我还没看完，你先帮我保管一下。”"
    "你思考了一下这是否违反规定。"
    cst "“如果我过几天忘了回来取，你再帮我登记归还吧。”"
    "你对她挺有好感的，就应下了。"
    "然后随手把那本书放进了服务台的柜子里。"
    

    scene library with fade
    "【现在】"
    show nx at center with dissolve
    
    "你翻开了那本小说的封底。"
    "发现里面夹着一把黄铜钥匙。"
    "扁扁的、小小的，怪不得你没有发现。"
    "钥匙上贴着一个标签，上面写着：老城区康庄路44号502。"
    "取出钥匙的同时，你注意到了小说结尾的那句话。"
    "“那些我没有说出口的话，最后成了刺。”"
    "你突然不合时宜地想，她应该是看完了这本书的。"
    menu:
        "去康庄路44号看看":
            jump chapter_2

label chapter_2:
    scene black with fade
    centered "第二章：笔记本"
    show screen notebook_hud

    show stairway at flickering_light
    "老城区康庄路44号。"
    "五楼，没有电梯。楼道里的声控灯坏了一半，忽明忽暗。"
    "这里不是陈思彤的家，大概是她为了调查，秘密租下的安全屋。"
    "警察好像还没有查到这里。"
    
    queue sound door
    scene room_chen with dissolve
    show nx at center with dissolve
    
    "房间很小，但收拾得很干净。"
    "书桌上摊着几本画册，一杯早已干涸的咖啡。"
    "左边的沙发床上放着一个黑色的笔记本。"
    "你翻开了那本笔记本。"
    
    window hide
    call screen click_notebook_area
    play sound page

    label notebook_loop:
        scene room_chen with dissolve
        call screen notebook_index
        $ choice = _return

        if choice == "solve":
            window hide
            menu:
                "你看得差不多了，决定把这本笔记先保存在自己手里。":
                    $ show_notebook_icon = True
                    show screen notebook_hud
                    "你拿到了陈思彤的笔记本，现在可以随时点击右上角查看了。"
                    "然后你翻回了第18页，盯着那个熟悉的名字——青石中心学校。"
                    jump chapter_3
                "你把笔记内容都记住了，又把它放回了原处。":
                    $ show_notebook_icon = False
                    "你合上了笔记本，把它放回了原本的位置。"
                    "不过，第18页上的那个名字——青石中心学校，已经深深印在了你的脑海里。"
                    jump chapter_3

        # 笔记本 1-30 页内容
        if choice == 1:
            "“如果我出事了，希望看到这本笔记的人，能替我走完最后的路。”"
            show nx with dissolve
            n "“为什么是我呢？”"
        elif choice == 2:
            "“小禾总是半夜惊醒。她才21岁，却因为严重的抑郁症不得不休学。”"
            show nx with dissolve
            n "“她好像说过她有一个可爱的妹妹。”"
        elif choice == 3:
            "“我看了她的手机，那个叫孙曼清的女人，是带头霸凌她的人。”"
        elif choice == 4:
            "左下角有一行极小的铅笔字：“小禾 2005.3.21。那是全家最开心的一天。”"
            show nx with dissolve
            n "“2005年3月21日……这是她妹妹的生日吗？”"
        elif choice == 5:
            "手绘的组织架构草图。最上面写着“翔云科技”，下面画着箭头指向“孙曼清”。"
            "旁边批注：“孙曼清只是个执行者，她背后是翔云科技的高管。”"
        elif choice == 6:
            "“翔云科技的CEO，高翔。我准备从这个人入手。”"
            show nx shock with dissolve
            n "好耳熟的名字，好像从哪听说过。"
        elif choice == 7:
            "“太可怕了……高翔的公司看似光鲜，背地里却有专门的团队替他处理‘脏活’，孙曼清就是其中之一。”"
        elif choice == 8:
            "“我黑进了他们的一部分内部网络，拷贝了资料。云盘的密码，是我一切调查的起点。”"
            show nx shock with dissolve
            n "“云盘密码？”"
        elif choice == 9:
            "“高翔的恶不是现在才开始的。”"
            show nx closeeye with dissolve
            n "什么意思？"
        elif choice == 10:
            "一串数字：“20031012。”“他初三毕业后就匆匆出国了，为什么？”"
            show nx with dissolve
            n "“这串数字好像是学号？"
        elif choice == 11:
            "“我顺着时间线往前查。2009年，有一桩被草草结案的坠楼事件。”"
            show nx closeeye with dissolve
            n "......"
        elif choice == 12:
            "一段被反复涂抹的字：“替罪羊……张浩。真正的凶手被保护起来了。”"
        elif choice == 13:
            "“张浩出狱后，在城郊的一家老化工厂做临时工。我远远地见过他一次，他看起来像个行尸走肉。”"
        elif choice == 14:
            "“他说：你放心。他说：我会处理。他说：不会有人知道。”"
            "下面用红笔批注：“高翔当年的录音残段”"
        elif choice == 15:
            "“我找到了当年的死者家属。她哥哥叫林远，这些年他竟然潜伏进了翔云科技......”"
        elif choice == 16:
            "“林远给了我很多关键证据，我全部存进了秘密云盘。”"
        elif choice == 17:
            "“我需要当年的直接目击证据。”"
            "“林远说，当年其实有个发帖人，好像是路过刚好拍到了一张照片。”"
        elif choice == 18:
            "“青石中心学校”——单独一行，下面用红笔画了一条线。"
            show nx shock with dissolve
            n "“这不是我上小学的学校吗？！”"
        elif choice == 19:
            "“我给论坛上的那个帖子的发帖人私信后，她回我她叫周瑶。”"
            n "“发帖人叫周瑶……”"
        elif choice == 20:
            "“周瑶说，她在新帖子的评论区放了一个附件，密码就是时间。”"
        elif choice == 21:
            "空白。只有一滴咖啡渍，似乎记录者在这里停顿了很久。"
        elif choice == 22:
            "“周瑶说，当年除了她，其实还有一个人可能看到了什么。”"
        elif choice == 23:
            "“一个小学部的女孩。她当时就站在操场边的梧桐树下。”"
        elif choice == 24:
            "“我找到她了。那个女孩现在长大了，在老街的一家图书馆工作。”"
            "“妹妹之前也喜欢看书，如果她还在的话......”"
            show nx shock with dissolve
            n "“......我吗？她妹妹发生了什么？”"
        elif choice == 25:
            "“高翔的人最近在跟踪我。他们可能发现我动了云盘的资料。”"
        elif choice == 26:
            "“我不打算把密码告诉林远，如果是他，他一定会拿着证据和高翔当面对质......”"
        elif choice == 27:
            "“我想去借书。有时间的话，我还想和那个图书管理员成为朋友。”"
        elif choice == 28:
            "“她把自己封闭了十七年。”"
            "“如果能让她亲手解开这一切，她的创伤是不是就能痊愈？”"
            show nx closeeye with dissolve
            n "“她怎么知道的......”"
            "你讨厌这种情绪不受控制的感觉。"
            "你明明已经要把你自己也骗过去了。"
            n "“所以我一直没能走出那个下午吧。”"
            show nx with dissolve
        elif choice == 29:
            "“这把钥匙，就夹在小说里吧。”"
        elif choice == 30:
            "最后一页只有一句话，字迹很轻。"
            "“宁寻，对不起把你卷进来。”"
            "“但请你替我们，也替你自己，走到最后。”"
            show nx with dissolve
            n "“我知道了。”"
        menu:
            "返回笔记本目录":
                jump notebook_loop
    

label chapter_3:
    # 【三、十七年前的黄昏】
    scene black with fade
    centered "第三章：十七年前的黄昏"
    
    scene school with dissolve 
    
    "“青石中心学校”……那是你以前的学校。"
    "你九岁那年，在那所学校里，你看到了一辈子都忘不掉的画面。"
    "一个戴着蓝色发卡的女孩子，躺在血泊里。"
    
    queue sound flashback
    pause 1.0
    scene black with hpunch
    
    "画面开始抖动。颜色褪去，只剩昏黄。"
    
    play sound "heartbeat.mp3" loop
    "你听到了心跳声。"
    "模糊的画面。看不清脸，只有颜色——红色，蓝色。"
    "红色是血，蓝色是发卡。"
    
    "然后画面消失了。"
    stop sound fadeout 1.0
    
    show nx closeeye with dissolve
    n "“……又来了。”"
    "你闭上眼睛，深呼吸。"
    "你想起那天晚上，你一个人坐在房间里，那个画面一遍一遍地重放。"
    scene n_room_9 with dissolve
    "没有人告诉你“做别的事来转移注意力”"
    "没有人告诉你“这事和你没关系”。"
    "你只能自己扛着，扛了十七年。"
    scene black with dissolve
    "但现在不一样了。"
    "陈思彤把寻找真相的钥匙交给了你。"
    show nx with dissolve
    n "“我不能再逃避了。”"
    
    jump chapter_4

label chapter_4:
    # 【四、匿名者】
    scene black with fade
    centered "第四章：匿名者"
    
    scene library with dissolve
    show nx at center with dissolve
    
    "你回到图书馆，坐在电脑前，打开了搜索框。"
    "你想起了陈思彤笔记里提到的地点和年份。"
    
    label search_loop:
        $ search_term = renpy.input("在搜索框中输入关键词：", length=20)
        
        if "青石" in search_term and "2009" in search_term:
            "搜索结果出来了，你看到了一个论坛帖子。"
        else:
            sys "没有找到有用的结果。"
            jump search_loop


    scene black with fade
    show forum at truecenter with dissolve
    
    "帖子是2019年发的，匿名。"
    "主楼只有一张照片和一行字。"
    "照片很模糊，你点了进去。"
    
    window hide
    call screen click_blurred_photo
   
    scene black 
    show photo at truecenter with dissolve # 换成你清晰照片的变量名
    
    window show
    "照片变得清晰。你看清了地上的女孩，她的头上戴着蓝色发卡。"
    "这个对女孩施暴的人......他穿着初中部的校服。"
    "你的手开始不受控制地发抖。"
    n "“那天下午……还有第三个人。”"
    n "“照片的右下角是......”"
    "你想起了什么，点开了评论区的加密文件。"
    
    jump password_1752
  
        
    label password_1752:
        $ input_time = renpy.input("请输入密码：", length=4, allow="0123456789")
        if input_time == "1752":
            scene black with dissolve
            "屏幕跳转。"
            "那是一份录音文件。"
            show zy with dissolve
            "“那天我在那里，我拍了这张照片。”"
            "“后来有人找到我，给了我一笔钱，威胁我让我删掉。”"
            "“我当时太害怕了，所以我把帖子删了。”"
            "“不过照片我一直有留着备份。”"
            "“现在我确诊了绝症。”"
            "“我没有时间了。”"
            "“如果还有人在乎的话，如果能帮到你的话。”"
            "“这是我能做的最后一件事。”"
            hide zy with dissolve
        else:
            play sound ms
            sys "密码错误。"
            jump password_1752
            
    label identity_zhouyao:
        $ input_name_1 = renpy.input("你知道这个发帖的“我”是谁：", length=10)
        if input_name_1 == "周瑶":
    
            "你找到了一个校内网页面。"
            "她的头像是一朵莲花。"
            "最后一条动态也停留在2019年3月。"
            show zy with dissolve
            zy "“对不起。这是我能做的最后一件事了。”"
            "周瑶就是那个路过的人，那个拍下照片的人。"
            hide zy with dissolve
        else:
            sys "不对吧。"
            jump identity_zhouyao
            
    label identity_zhanghao:
        $ input_name_2 = renpy.input("你知道照片里那个穿着初中部校服的人是谁：", length=10)
        if input_name_2 == "张浩":
            menu:
                "去找张浩":
                    jump chapter_5
        else:
            sys "好像不是。"
            jump identity_zhanghao


label chapter_5:
    # 【五、工厂里的鬼魂】
    scene black with fade
    centered "第五章：工厂里的鬼魂"
    
    scene factory with fade
    "顺着陈思彤的笔记线索，你找到了张浩的地址。"
    "他在城郊一个工厂上班。"
   
    show zh with dissolve
    "工厂门口。"
    "张浩穿着灰色工装，头发白了一半。的确看起来就像个行尸走肉。"
    "你走上前，拦住了他。"
    show zh with dissolve:
        xoffset 400
    show nx at left with dissolve:
        xoffset -400
    label zhanghao_q1:
        menu:
            "“2009年，青石中心学校，你记得吗？”":
                show zh flust 
                "张浩停下来，看着你。原本麻木的眼神里闪过一丝极度的慌乱。"
            "“你是张浩吗？”":
                "张浩没理你，转身走了。"
                jump zhanghao_q1
            "“林芷。”":
                "听到这个名字，他像触电一样避开你的眼神，转身走了。"
                jump zhanghao_q1
                
    label zhanghao_q2:
        menu:
            "“我是记者。”":
                "张浩皱起眉头，转身走了。"
                jump zhanghao_q1
            "“我是林芷的同学。”":
                "张浩的脸色煞白。"
            "“我是警察。”":
                "张浩冷笑一声：“警察十七年前就结案了。”转身走了。"
                jump zhanghao_q1
                
    label zhanghao_q3:
        menu:
            "“有人拍了照片。2009年9月20日17:52。”":
                "张浩彻底僵住了，他沉默了很长时间。"
            "“你杀了人。”":
                "张浩愤怒地推开你：“我坐过牢了！”走了。"
                jump zhanghao_q1
            "“高翔让我来的。”":
                "张浩惊恐地连连后退，跑回了工厂。"
                jump zhanghao_q1
                
    show zh 
    z "“……是翔哥让我去的。”"
    n "“翔哥是谁？”"
    z "“我不知道。我只知道他姓高，比我高一届，家里很有钱。”"
    z "“我只是个顶罪的……”"
    
    hide zh with dissolve
    "张浩逃似地走进工厂，大门在你面前重重关上。"

label chapter_6:
    # 【六、坠落之日】
    scene black with fade
    centered "第六章：坠落之日"
    window hide 
    play sound "flashback.mp3" 
    scene black with hpunch    
    
    
    "画面再次抖动，这一次前所未有地清晰。"
    show lz with Fade(0.1, 0.0, 0.5, color="#8b0000") # 暗红色闪屏特效
    play sound "heartbeat.mp3" loop
    "你看到了林芷的脸，你听到了自己当年的心跳声。"
    hide lz with dissolve

    stop sound fadeout 1.0
    scene factory with dissolve
    show nx with dissolve
    
    window show
    n "“林芷……这次我一定要找到高翔的犯罪证据。”"
    "根据陈思彤的笔记，林芷的哥哥林远手里有关键线索。"
    menu:
        "去找林远":
            jump chapter_7

label chapter_7:
    scene black with fade
    centered "第七章：十七年的守夜人"
    
    scene lin_door with dissolve
    "林远的家。"
    "六楼，没有电梯。"
    play sound knock
    "你敲了三下门，门开了。"
    queue sound door
    show ly with dissolve
    l "“你是谁？”"
    show ly with dissolve:
        xoffset 400
    show nx with dissolve:
        xoffset -400
    

    n "“我叫宁寻。陈思彤把钥匙留给了我。”"
    "他的眼神剧烈地变了一下，侧身让开。"
    l "“进来。”"
    
    scene lin_home with dissolve
    
    
    "客厅墙上挂着一张黑白照片。"
    "一个扎马尾的女孩，笑得眼睛弯弯的。"
    "你认出了她，认出了那个蓝色发卡。"
    show ly with dissolve:
        xoffset 400    
    show nx with dissolve:
        xoffset -400

    
    l "“我等了十七年。”"
    n "“你既然潜伏在高翔身边，为什么陈思彤不直接把云盘密码告诉你？”"
    
    "林远看着你，苦笑了一下。"
    l "“因为她查到了你。”"
    l "“她说，我是为了仇恨活着的。”"
    l "“一旦我拿到证据，我大概率会和高翔同归于尽。”"
    l "“但你不一样。”"
    l "“她说，你只是一个被十七年前那个下午困住的无辜者。”"
    
    show nx shock with dissolve
    queue sound "<from 0 to 1.0>audio/heartbeat.mp3"
    "你的心猛地跳了一下。"
    
    
    l "“思彤说，最后一把锁，必须由那个被困在原地的目击者亲自打开。”"
    l "“只有让你亲自拼凑出真相……”"
    l "“只有这样，你心里的那场雨才会停歇。”"
    
    show nx closeeye with dissolve
    "眼泪突然毫无征兆地砸了下来。"
    "那个只见过几面的读者。"
    "那个总是帮你整理书籍的女人。"
    "竟然用生命为你铺好了一条救赎的路。"
    
    show nx with dissolve
    n "“云盘在哪里？我知道密码。”"
    hide nx with dissolve
    hide ly with dissolve
    
    label password_20050321:
        $ input_pw = renpy.input("输入云盘密码：", length=8, allow="0123456789")
        if input_pw == "20050321":
            "云盘打开了，里面是陈思彤的全部调查资料。"
            jump chapter_8
        else:
            play sound ms
            sys "密码错误。请回忆笔记本中记录的日期。"
            jump password_20050321

label chapter_8:
    # 【八、青石之下】
    scene black with fade
    play music jw fadein 2.0
    centered "第八章：青石之下"
    
    scene library with fade
    
    "【几天后】"
    "图书馆。"
    show nx with dissolve
    "你站在服务台后面，手机屏幕亮了一下。"
    "一则新闻推送。"
    "【翔云科技CEO高翔因涉嫌多起凶杀案件、商业犯罪被警方正式逮捕。】"
    
    "你读了两遍，按灭了屏幕。"
    hide nx with dissolve
    "窗外的梧桐树被风吹得沙沙响，有几片叶子落下来。"
    
    "你想起十七年前，林芷站在你桌前。"
    scene school with dissolve
    show lz at right with dissolve
    lz "“能不能借我一支笔。”"
    show lz with dissolve:
        xoffset 350
    show nx 9 with dissolve:
        xoffset -280
        zoom 0.8
        yoffset 220
    n "“嗯。”"
    
    
    "你正在写作业，头也没太抬，只把笔递了过去。"
    lz "“谢谢。”"
    "你抬头看了她一眼——她头上的蓝色发卡很好看。"
    "然后她走了。"
    hide lz with dissolve
    hide nx 9 with dissolve
    
    scene black with dissolve
    show nx with dissolve
    "你当时没有多想。"
    show nx closeeye with dissolve
    "后来，你却用十七年去回想那个下午。"
    "如果当时你多看她一眼。"
    "如果当时你问她一句“你还好吗？”"
    "如果当时你追上去……"
    "她是不是就不会死？"
    show nx with dissolve
    "这个念头像一根刺，扎了十七年。"
    "但现在，你知道真相了。"
    show nx closeeye with dissolve
    "林芷的死，与你有没有多看她一眼无关。"
    "与你做什么、不做什么，都没有关系。"
    show nx with dissolve
    "那是纯粹的，自以为是上位者而对弱者的作恶。"
    "撕开这层黑暗给你看的，是那个名叫陈思彤的女人。"
    "某种程度上，她用自己的生命作为引线，把你从十七年的自责里拽了出来。"
    show nx closeeye with dissolve
    "你闭上眼睛，深吸一口气。"
    
    "好像看到了九岁的林芷，也看到了那个不知所措的自己。"
    show nx with dissolve

    hide nx
    show lz:
        xoffset 350
    show nx 9:
        xoffset -280
        zoom 0.8
        yoffset 220
        
    with Dissolve(2)

    "她们在对你微笑。"
    $ show_notebook_icon = False        

    # 2. 制作组名单
    stop music fadeout 3.0
    scene black with fade
    pause 1.0
    
    show text "{size=40}青石之下，十七年。{/size}\n\n{size=40}刺已拔出。{/size}" at truecenter
    with Dissolve(2.0)
    pause 3.0 
    hide text with Dissolve(2.0)
    
    show text "愿校园霸凌、职场霸凌都不再发生。\n\n如果你正遭受霸凌，请一定要积极求助身边的人。\n保护好自己，逃出来。\n\n有余力的话，再成长为可以保护别人的人。" at truecenter
    with Dissolve(1.5)
    pause 4.0
    hide text with Dissolve(1.5)
    pause 1.0

    # 2. 制作组名单
    show text "{size=35}【《青石之下》制作组】{/size}\n\n策划 / 主笔：希\n\n美 术：盐 水\n\n程序 / 责编：Megalomaniac" at truecenter
    with Dissolve(1.5)
    pause 3.0
    hide text with Dissolve(1.5)
    pause 0.5
    
    # 3. 致谢
    show text "这算是我们三个人第一次真正意义上制作一款游戏。\n\n过程兵荒马乱，磕磕绊绊，但幸好坚持到了最后。" at truecenter
    with Dissolve(1.5)
    pause 3.5
    hide text with Dissolve(1.5)
    pause 0.5

    show text "感谢 【莉莉丝游戏】 提供的契机，\n让我们有了把脑海中的故事落地的勇气。\n\n同时也感谢这个包容的 AI 时代，\n让没有任何经验的我们，也能跨越技术的鸿沟，把心里的世界快速变成现实。" at truecenter
    with Dissolve(1.5)
    pause 4.5
    hide text with Dissolve(1.5)
    pause 1.0
    
    # 4. 最终致谢
    show text "{size=35}最后，感谢你的游玩。{/size}" at truecenter
    with Dissolve(2.0)
    pause 3.0
    hide text with Dissolve(2.0)
    pause 2.0
    
    menu:
        "结束游戏":
            pass

    return

# HUD 专属笔记本阅读循环
label read_notebook_from_hud:
    window hide
    call screen notebook_index
    # 获取玩家点击了哪个按钮
    $ choice = _return
    if choice == "solve":
        window show
        return 
        
    if choice == 1:
            "“如果我出事了，希望看到这本笔记的人，能替我走完最后的路。”"
    elif choice == 2:
            "“小禾总是半夜惊醒。她才21岁，却因为严重的抑郁症不得不休学。”"
    elif choice == 3:
            "“我看了她的手机，那个叫孙曼清的女人，是带头霸凌她的人。”"
    elif choice == 4:
            "左下角有一行极小的铅笔字：“小禾 2005.3.21。那是全家最开心的一天。”"
    elif choice == 5:
            "手绘的组织架构草图。最上面写着“翔云科技”，下面画着箭头指向“孙曼清”。"
            "旁边批注：“孙曼清只是个执行者，她背后是翔云科技的高管。”"
    elif choice == 6:
            "“翔云科技的CEO，高翔。我准备从这个人入手。”"
    elif choice == 7:
            "“太可怕了……高翔的公司看似光鲜，背地里却有专门的团队替他处理‘脏活’，孙曼清就是其中之一。”"
    elif choice == 8:
            "“我黑进了他们的一部分内部网络，拷贝了资料。云盘的密码，是我一切调查的起点。”"
    elif choice == 9:
            "“高翔的恶不是现在才开始的。”"
    elif choice == 10:
            "一串数字：“20031012。”“他初三毕业后就匆匆出国了，为什么？”"
    elif choice == 11:
            "“我顺着时间线往前查。2009年，有一桩被草草结案的坠楼事件。”"
            n "就是这个时间吧。"
    elif choice == 12:
            "一段被反复涂抹的字：“替罪羊……张浩。真正的凶手被保护起来了。”"
    elif choice == 13:
            "“张浩出狱后，在城郊的一家老化工厂做临时工。我远远地见过他一次，他看起来像个行尸走肉。”"
    elif choice == 14:
            "“他说：你放心。他说：我会处理。他说：不会有人知道。”"
            "下面用红笔批注：“高翔当年的录音残段”"
    elif choice == 15:
            "“我找到了当年的死者家属。她哥哥叫林远，这些年他竟然潜伏进了翔云科技......”"
    elif choice == 16:
            "“林远给了我很多关键证据，我全部存进了秘密云盘。”"
    elif choice == 17:
            "“我需要当年的直接目击证据。”"
            "“林远说，当年其实有个发帖人，好像是路过刚好拍到了一张照片。”"
    elif choice == 18:
            "“青石中心学校”——单独一行，下面用红笔画了一条线。"
            n "就是这个地点吧。"
    elif choice == 19:
            "“我给论坛上的那个帖子的发帖人私信后，她回我她叫周瑶。”"
    elif choice == 20:
            "“周瑶说，她在帖子的评论区放了一个附件，密码就是时间。”"
    elif choice == 21:
            "空白。只有一滴咖啡渍，似乎记录者在这里停顿了很久。"
    elif choice == 22:
            "“周瑶说，当年除了她，其实还有一个人可能看到了什么。”"
    elif choice == 23:
            "“一个小学部的女孩。她当时就站在操场边的梧桐树下。”"
    elif choice == 24:
            "“我找到她了。那个女孩现在长大了，在老街的一家图书馆工作。”"
            "“妹妹之前也喜欢看书，如果她还在的话......”"
    elif choice == 25:
            "“高翔的人最近在跟踪我。他们可能发现我动了云盘的资料。”"
    elif choice == 26:
            "“我不打算把密码告诉林远，如果是他，他一定会拿着证据和高翔当面对质......”"
    elif choice == 27:
            "“我想去借书。有时间的话，我还想和那个图书管理员成为朋友。”"
    elif choice == 28:
            "“她把自己封闭了十七年。”"
            "“如果能让她亲手解开这一切，她的创伤是不是就能痊愈？”"
    elif choice == 29:
            "“这把钥匙，就夹在小说里吧。”"
    elif choice == 30:
            "最后一页只有一句话，字迹很轻。"
            "“宁寻，对不起把你卷进来。”"
            "“但请你替我们，也替你自己，走到最后。”"
            
    jump read_notebook_from_hud

